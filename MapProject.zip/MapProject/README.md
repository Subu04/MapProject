
Title: A Website Using Google Maps API for Finding a particular plot/house in a large housing community 

Started On: 04/04/19

Status: In Progress 

Works Completed so far 

(10/04/19)

* Search Feature Included for looking up the correct plot and marking it.
* Custom flag is set for the searched plot
* On Search Markers are removed and only the intended plot is highlighted

Works to Do 

* Zoom Position Should be set to the precise layout
* Map Should not be refreshed on every click
* All the previous Markers should disappear and plot at that instance should be shown
* Styling the UI
* Pop Up Info About the Plot 
* Login 